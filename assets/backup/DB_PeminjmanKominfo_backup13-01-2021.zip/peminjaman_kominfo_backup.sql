#
# TABLE STRUCTURE FOR: barang
#

DROP TABLE IF EXISTS `barang`;

CREATE TABLE `barang` (
  `id_barang` int(11) NOT NULL AUTO_INCREMENT,
  `nama` varchar(128) NOT NULL,
  `kondisi` enum('baik','rusak') NOT NULL,
  `image` varchar(256) NOT NULL,
  PRIMARY KEY (`id_barang`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4;

INSERT INTO `barang` (`id_barang`, `nama`, `kondisi`, `image`) VALUES (1, 'LCD', 'baik', 'lcd1.jpg');
INSERT INTO `barang` (`id_barang`, `nama`, `kondisi`, `image`) VALUES (2, 'Layar Proyektor', 'baik', 'layar_proyektor1.jpg');


#
# TABLE STRUCTURE FOR: dinas
#

DROP TABLE IF EXISTS `dinas`;

CREATE TABLE `dinas` (
  `id_dinas` int(11) NOT NULL AUTO_INCREMENT,
  `nama_dinas` varchar(128) NOT NULL,
  PRIMARY KEY (`id_dinas`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4;

INSERT INTO `dinas` (`id_dinas`, `nama_dinas`) VALUES (3, 'Dinas Komunikasi dan Informatika');
INSERT INTO `dinas` (`id_dinas`, `nama_dinas`) VALUES (4, 'Dinas Pariwisata');
INSERT INTO `dinas` (`id_dinas`, `nama_dinas`) VALUES (5, 'Dinas Lingkungan Hidup');
INSERT INTO `dinas` (`id_dinas`, `nama_dinas`) VALUES (6, 'Satpol PP');
INSERT INTO `dinas` (`id_dinas`, `nama_dinas`) VALUES (7, 'Dinas Pertanian');
INSERT INTO `dinas` (`id_dinas`, `nama_dinas`) VALUES (8, 'Dinas Kesehatan');
INSERT INTO `dinas` (`id_dinas`, `nama_dinas`) VALUES (9, 'Dinas Perhubungan');
INSERT INTO `dinas` (`id_dinas`, `nama_dinas`) VALUES (10, 'Dinas Pemadam Kebakaran');
INSERT INTO `dinas` (`id_dinas`, `nama_dinas`) VALUES (11, 'Dinas PUPR Bina Marga');
INSERT INTO `dinas` (`id_dinas`, `nama_dinas`) VALUES (14, 'Dinas Ketahanan Pangan');
INSERT INTO `dinas` (`id_dinas`, `nama_dinas`) VALUES (17, 'Dinas Pendidikan');


#
# TABLE STRUCTURE FOR: peminjaman
#

DROP TABLE IF EXISTS `peminjaman`;

CREATE TABLE `peminjaman` (
  `id_peminjaman` int(11) NOT NULL AUTO_INCREMENT,
  `id_user` int(11) NOT NULL,
  `id_barang` int(11) NOT NULL,
  `tgl_peminjaman` date NOT NULL,
  `tgl_kembali` date NOT NULL,
  `keterangan` text NOT NULL,
  `status_peminjaman` enum('0','1') NOT NULL,
  `status_pengembalian` enum('sudah','belum') NOT NULL,
  PRIMARY KEY (`id_peminjaman`),
  KEY `id_user` (`id_user`,`id_barang`),
  KEY `id_barang` (`id_barang`),
  CONSTRAINT `peminjaman_ibfk_1` FOREIGN KEY (`id_barang`) REFERENCES `barang` (`id_barang`),
  CONSTRAINT `peminjaman_ibfk_2` FOREIGN KEY (`id_user`) REFERENCES `user` (`id_user`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4;

INSERT INTO `peminjaman` (`id_peminjaman`, `id_user`, `id_barang`, `tgl_peminjaman`, `tgl_kembali`, `keterangan`, `status_peminjaman`, `status_pengembalian`) VALUES (1, 8, 1, '2021-01-12', '2021-01-15', 'Untuk acara penting', '1', 'belum');
INSERT INTO `peminjaman` (`id_peminjaman`, `id_user`, `id_barang`, `tgl_peminjaman`, `tgl_kembali`, `keterangan`, `status_peminjaman`, `status_pengembalian`) VALUES (2, 7, 2, '2021-01-13', '2021-01-14', 'Untuk rapat', '0', 'belum');


#
# TABLE STRUCTURE FOR: user
#

DROP TABLE IF EXISTS `user`;

CREATE TABLE `user` (
  `id_user` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(128) NOT NULL,
  `id_dinas` int(11) NOT NULL,
  `email` varchar(128) NOT NULL,
  `image` varchar(128) NOT NULL,
  `password` varchar(256) NOT NULL,
  `id_role` int(1) NOT NULL,
  `is_active` enum('aktif','pasif') NOT NULL,
  `date_created` int(11) NOT NULL,
  PRIMARY KEY (`id_user`),
  KEY `id_dinas` (`id_dinas`),
  KEY `id_role` (`id_role`),
  CONSTRAINT `user_ibfk_1` FOREIGN KEY (`id_dinas`) REFERENCES `dinas` (`id_dinas`),
  CONSTRAINT `user_ibfk_2` FOREIGN KEY (`id_role`) REFERENCES `user_role` (`id_role`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4;

INSERT INTO `user` (`id_user`, `name`, `id_dinas`, `email`, `image`, `password`, `id_role`, `is_active`, `date_created`) VALUES (4, 'Winandri Kusuma', 3, 'andri@gmail.com', 'petertnak.png', '$2y$10$nK8Hn0AmGYKrIs9HJIUNie8RlwPCF3oIAIAl5n95JrxHg2AB5q6pm', 1, 'aktif', 1604837683);
INSERT INTO `user` (`id_user`, `name`, `id_dinas`, `email`, `image`, `password`, `id_role`, `is_active`, `date_created`) VALUES (7, 'coba', 4, 'narutomimimi@gmail.com', 'default.png', '$2y$10$OhDGLMd/gIiZ.YWEXxPypOB68SJQQBdZ/82euoq3yWfULCwv8nniy', 2, 'aktif', 1610359846);
INSERT INTO `user` (`id_user`, `name`, `id_dinas`, `email`, `image`, `password`, `id_role`, `is_active`, `date_created`) VALUES (8, 'fandi', 6, 'fandi.zahiradana@gmail.com', 'default.png', '$2y$10$Hb.IWMurPa7uYDguWHvcKeBbM9G8cuF6EfAZ/0JkSk3SMeEyOgfHC', 2, 'pasif', 1610359986);
INSERT INTO `user` (`id_user`, `name`, `id_dinas`, `email`, `image`, `password`, `id_role`, `is_active`, `date_created`) VALUES (9, 'cccc', 5, 'coba2@gmail.com', 'default.png', '$2y$10$Trv2SjUQwJO85s3xpTWAlujXKCNXbVvFCG7yzIBT6aSR7JhFxuRH2', 2, 'pasif', 1610386221);
INSERT INTO `user` (`id_user`, `name`, `id_dinas`, `email`, `image`, `password`, `id_role`, `is_active`, `date_created`) VALUES (10, 'aaa', 11, 'robert@gmail.com', 'default.png', '$2y$10$4h3CQHNQwI88nabtacb79.ucp5NmiYc9q7D.ChuUgyRuEgCYhYXhW', 2, 'pasif', 1610552184);


#
# TABLE STRUCTURE FOR: user_role
#

DROP TABLE IF EXISTS `user_role`;

CREATE TABLE `user_role` (
  `id_role` int(11) NOT NULL AUTO_INCREMENT,
  `role` varchar(128) NOT NULL,
  PRIMARY KEY (`id_role`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4;

INSERT INTO `user_role` (`id_role`, `role`) VALUES (1, 'admin');
INSERT INTO `user_role` (`id_role`, `role`) VALUES (2, 'admin');


#
# TABLE STRUCTURE FOR: user_token
#

DROP TABLE IF EXISTS `user_token`;

CREATE TABLE `user_token` (
  `id_token` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(128) NOT NULL,
  `token` varchar(128) NOT NULL,
  `date_created` int(11) NOT NULL,
  PRIMARY KEY (`id_token`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4;

INSERT INTO `user_token` (`id_token`, `email`, `token`, `date_created`) VALUES (1, 'narutomimimi@gmail.com', 'nXJmNztJXQyZVSFTEE3i/uFS4R3fBPw5b9gGg9bOvQc=', 1610359846);
INSERT INTO `user_token` (`id_token`, `email`, `token`, `date_created`) VALUES (2, 'fandi.zahiradana@gmail.com', 'qhT4LJ+7ypY1fWAKzxzJqUkGEGGUxVC9FyUemTMywLM=', 1610359986);
INSERT INTO `user_token` (`id_token`, `email`, `token`, `date_created`) VALUES (3, 'coba2@gmail.com', 'Ptj9+kT8V5IoMshLqIU0zayihCpiIQP3jdnYl4ia+wE=', 1610386221);
INSERT INTO `user_token` (`id_token`, `email`, `token`, `date_created`) VALUES (4, 'robert@gmail.com', 'sdFrSUIwStuMInys9qP9XLTsVJP5Z4uH1KyuPU1XYxk=', 1610552184);


